var express = require('express');
var path = require('path');
var logger = require('morgan');
var bodyParser = require('body-parser');
const neo4j = require('neo4j-driver');
const driver = neo4j.driver("bolt://localhost:7687", neo4j.auth.basic("neo4j", "123456"));
let session;
let cypher = "";
var app = express();
let segments = [];
function timeDifference(time1, time2) {
    mints1 = parseInt(time1.split(":")[0]) * 60 + parseInt(time1.split(":")[1])
    mints2 = parseInt(time2.split(":")[0]) * 60 + parseInt(time2.split(":")[1])
    if(mints2 >= mints1) {
        return mints2-mints1;
    }
    else {
        return 60*60 - (mints1-mints2);
    }
}
function getUpdatedSegments(record) {
    let totalTime=0, totalDistance=0, totalCost=0,layoverTime=0;
    for(var index =0 ; index < record["_fields"][0].segments.length; index++) {
        segment = record["_fields"][0].segments[index];
        prevSegment = record["_fields"][0].segments[index-1];
        totalTime += segment.relationship.properties.duration.low
        totalCost += segment.relationship.properties.cost.low
        totalDistance += segment.relationship.properties.distance
        if(index>0) {
            layoverTime += timeDifference(segment.relationship.properties.departureTime, prevSegment.relationship.properties.arrivalTime)
        }
    }
    const segmentData = {
        path: record["_fields"][0].segments,
        cost: totalCost,
        speed: (totalDistance*60)/(totalTime+layoverTime)
    }
    return segmentData;
}
app.get('/',async function(req,res) {
    session = driver.session();
    cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:FLIGHT*1..1]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 10"
    await session.run(cypher).then(function(result) {
        result.records.forEach((record, index) => {
            const segmentData = getUpdatedSegments(record)
            segments.push(segmentData)
            //console.log(record["_fields"][0].segments[0].relationship.properties.cost.low)
        });
    })
    .catch(function(err) {
        console.log(err);
    })
    session = driver.session();
    cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:ROAD*1..1]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 10"
    await session.run(cypher).then(function(result) {
        result.records.forEach((record, index) => {
            const segmentData = getUpdatedSegments(record)
            segments.push(segmentData)
        });
    })
    .catch(function(err) {
        console.log(err);
    })
    cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:FLIGHT*2..2]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 20"
    await session.run(cypher).then(function(result) {
        result.records.forEach((record, index) => {
            const segmentData = getUpdatedSegments(record)
            segments.push(segmentData)
        });
    })
    .catch(function(err) {
        console.log(err);
    })
    cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:ROAD*2..2]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 20"
    await session.run(cypher).then(function(result) {
        result.records.forEach((record, index) => {
            const segmentData = getUpdatedSegments(record)
            segments.push(segmentData)
        });
    })
    .catch(function(err) {
        console.log(err);
    })
    cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:ROAD|:FLIGHT*3..3]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 10"
    await session.run(cypher).then(function(result) {
        result.records.forEach((record, index) => {
            const segmentData = getUpdatedSegments(record)
            segments.push(segmentData)
        });
    })
    .catch(function(err) {
        console.log(err);
    })
    segments.forEach((segment, index) => {
        console.log(index,"-------",segment.cost, segment.speed)
    })
    res.send("hi its done");
})

app.listen(3000);
console.log("server listen on port 3000");