var express = require('express');
var path = require('path');
var logger = require('morgan');
var bodyParser = require('body-parser');
const neo4j = require('neo4j-driver');
const driver = neo4j.driver("bolt://localhost:7687", neo4j.auth.basic("neo4j", "123456"));
const session = driver.session();
//const cypher = 'MATCH (n) RETURN n';
const cypher = "MATCH p=(:Loc{name:'Delhi'})-[r:ROAD|:FLIGHT*1..3]->(:Loc{name:'Mumbai'}) RETURN p LIMIT 10"
var app = express();
app.get('/', function(req,res) {
    session.run(cypher)
    .then(function(result) {
        // result.records.forEach(element => {
        //     console.log("------anwar")
        //     console.log(element)
        // });
        result.records.forEach((record, index) => {
            console.log("------anwar", index)
            console.log(record["_fields"][0].segments)
        });
        

        // Node
        // const record = result.records[0]
        // console.log(record["_fields"],"--------")
        // console.log(record["_fields"][0].start,"--------")
        // console.log(record["_fields"][0].start.properties.name,"--------")
        // Node

        // Path start end
        // const record = result.records[0]
        // console.log(record["_fields"],"--------")
        // console.log(record["_fields"][0].segments,"--------")
        // console.log(record["_fields"][0].segments[0].start.properties.name,"--------")
        // console.log(record["_fields"][0].segments[0].end.properties.name,"--------")
        // console.log(record["_fields"][0].segments[1].start.properties.name,"--------")
        // console.log(record["_fields"][0].segments[1].end.properties.name,"--------")
        // Path start end
        

    })
    .catch(function(err) {
        console.log(err);
    })
    res.send("hi its done");
})

app.listen(3000);
console.log("server listen on port 3000");





// MERGE (a:Loc {name:"PUNE"})
// MERGE (b:Loc {name:"MUMBAI"})
// MERGE (c:Loc {name:"DELHI"})
// MERGE (d:Loc {name:"CHENNAI"})
// MERGE (e:Loc {name:"GOA"})
// MERGE (a)-[:ROAD {cost:500}]->(b)
// MERGE (a)-[:flight {cost:1000}]->(c)
// MERGE (c)-[:ROAD {cost:400}]->(b)
// MERGE (d)-[:flight {cost:40}]->(b)
// MERGE (c)-[:ROAD {cost:80}]->(e)
// MERGE (d)-[:flight {cost:30}]->(a)
// MERGE (c)-[:ROAD {cost:80}]->(b)





// MATCH (start:Loc{name:'PUNE'}), (end:Loc{name:'MUMBAI'})
// CALL algo.shortestPath.stream(start, end, 'cost')
// YIELD nodeId, cost
// RETURN algo.asNode(nodeId).name AS name, cost